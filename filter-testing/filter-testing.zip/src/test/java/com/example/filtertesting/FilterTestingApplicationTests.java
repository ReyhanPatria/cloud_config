package com.example.filtertesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilterTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
