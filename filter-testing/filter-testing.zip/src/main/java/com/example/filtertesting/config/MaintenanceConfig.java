package com.example.filtertesting.config;

import java.util.List;

import com.example.filtertesting.filter.MaintenanceFilter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

import lombok.Getter;
import lombok.Setter;

@Configuration
@ConfigurationProperties(prefix = "maintenance")
@Setter @Getter
public class MaintenanceConfig {
    private List<String> urls;

    @Bean
    public FilterRegistrationBean<MaintenanceFilter> filterRegistrationBean() {
        FilterRegistrationBean<MaintenanceFilter> registrationBean = new FilterRegistrationBean<>();
        MaintenanceFilter maintenanceFilter = new MaintenanceFilter();

        registrationBean.setFilter(maintenanceFilter);
        for(String url: urls) {
            registrationBean.addUrlPatterns(url);
        }
        registrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE);
        
        return registrationBean;
    }
}