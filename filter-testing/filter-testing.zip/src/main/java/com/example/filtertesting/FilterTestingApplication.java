package com.example.filtertesting;

import java.util.List;

import com.example.filtertesting.config.MaintenanceConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class FilterTestingApplication {
	@Autowired
	private MaintenanceConfig maintenanceConfig;

	public static void main(String[] args) {
		SpringApplication.run(FilterTestingApplication.class, args);
	}

	@GetMapping("/")
	public List<String> getHome() {
		return maintenanceConfig.getUrls();
	}

	@GetMapping("/not-in-maintenance")
	public String notInMaintenance() {
		return "Not in maintenance";
	}

	@GetMapping("/not-in-maintenance/in-maintenance")
	public String inMaintenance() {
		return "Should be redirected";
	}

	@GetMapping("/not-in-maintenance/in-maintenance/deep")
	public String inMaintenanceDeep() {
		return "Should be redirected";
	}

	@GetMapping("/maintenance")
	public String getMaintenance() {
		return "Current endpoint is under maintenance";
	}
}
